package geometry;

import java.awt.Color;
import java.awt.Graphics;

import drawing.DlgLine;
import drawing.PnlDrawing;

public class Line extends Shape{
	
	private Point startPoint;
	private Point endPoint;
	
	public Line() {
		
	}
	
	public Line(Point startPoint, Point endPoint) {
		this.startPoint = startPoint;
		this.endPoint = endPoint;
	}
	
	public Line(Point startPoint, Point endPoint, boolean selected) {
		this(startPoint, endPoint);
		this.selected = selected;
	}
	
	@Override
	public String toString() {
		return "Line [start= " + startPoint + " , end= " + endPoint + " , selected= " + isSelected() + "]";
		}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Line) {
			Line temp = (Line) o;
			if(startPoint.equals(temp.getStartPoint())) {
				return true;
			}
		}
		return false;
	}
	
	public Point middleOfLine() {
		int middleByX = (startPoint.getX()+endPoint.getX())/2;
		int middleByY = (startPoint.getY()+endPoint.getY())/2;
		Point mid = new Point(middleByX,middleByY);
		return mid;
	}
	
	public double length() {
		return startPoint.distance(endPoint); 
	}

	public Point getStartPoint() {
		return startPoint;
	}

	public void setStartPoint(Point startPoint) {
		this.startPoint = startPoint;
	}

	public Point getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(Point endPoint) {
		this.endPoint = endPoint;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(getOutline());
		g.drawLine(startPoint.getX(), startPoint.getY(), endPoint.getX(), endPoint.getY());
		if(isSelected()==true) {
			g.setColor(Color.black);
			g.drawRect(startPoint.getX()-3, startPoint.getY()-3, 6, 6);
			g.drawRect(endPoint.getX()-3, endPoint.getY()-3, 6, 6);
			g.drawRect(this.middleOfLine().getX()-3, this.middleOfLine().getY()-3, 6, 6);
		}
	}

	@Override
	public boolean contains(int x, int y) {
		Point click  = new Point(x,y);
		return (startPoint.distance(click) + endPoint.distance(click)) - length() <= 0.1;
	}

	@Override
	public void move(int newX, int newY) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void DialogEdit() {
		DlgLine dlgLine = new DlgLine();
		for(Shape shape : PnlDrawing.shapesArrList) {
			if(shape.isSelected()) {
				String[] split = shape.toString().split(" ");
				dlgLine.getTxtXstart().setText(split[4]);
				dlgLine.getTxtYstart().setText(split[7]);
				dlgLine.getTxtXend().setText(split[15]);
				dlgLine.getTxtYend().setText(split[18]);
			}
		}
		dlgLine.setVisible(true);
	}

	@Override
	public void AreaPainter(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
