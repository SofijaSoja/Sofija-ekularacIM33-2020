package geometry;

import java.awt.Color;
import java.awt.Graphics;

import drawing.DlgRectangle;
import drawing.PnlDrawing;

public class Rectangle extends Shape{
	
	private Point upperLeft;
	private int width;
	private int heigth;
	
	public Rectangle() {
		
	}
	
	public Rectangle(Point upperLeft, int width, int heigth) {
		this.upperLeft = upperLeft;
		this.width = width;
		this.heigth = heigth;
	}
	
	public Rectangle(Point upperLeft, int width, int heigth, boolean selected) {
		this(upperLeft, width, heigth);
		this.selected = selected;
	}
	
	@Override
	public String toString() {
		return "Rectangle [upl= " + upperLeft + " , width= " + width + " , height= " + heigth + " , selected= " + selected + "]";
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Rectangle) {
			Rectangle temp = (Rectangle) o;
			if(width==temp.getWidth() && heigth==temp.getHeight()) {
				return true;
			}
		}
		return false;
	}

	public Point getUpperLeft() {
		return upperLeft;
	}

	public void setUpperLeft(Point upperLeft) {
		this.upperLeft = upperLeft;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return heigth;
	}

	public void setHeight(int heigth) {
		this.heigth = heigth;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(getOutline());
		g.drawRect(upperLeft.getX(),upperLeft.getY(), width, heigth);
		if(isSelected()) {
			g.setColor(Color.black);
			g.drawRect(this.upperLeft.getX()-3, this.upperLeft.getY()-3, 6, 6);//gore levo
			g.drawRect(this.upperLeft.getX()+this.width-3, this.upperLeft.getY()-3, 6, 6);//gore desno
			g.drawRect(this.upperLeft.getX()-3, this.upperLeft.getY()+this.heigth-3, 6, 6);//dole levo
			g.drawRect(this.upperLeft.getX()+this.width-3, this.upperLeft.getY()+this.heigth-3, 6, 6);//dole desno
			
		}
		
	}

	@Override
	public boolean contains(int x, int y) {
			return (x >= upperLeft.getX() && x<= upperLeft.getX() + width)
					&& (y >= upperLeft.getY() && y <= upperLeft.getY() + heigth);
	}

	@Override
	public void move(int newX, int newY) {
		upperLeft.move(newX, newY);
		
	}

	@Override
	public void DialogEdit() {
		DlgRectangle dlgRectangle = new DlgRectangle();
		for(Shape shape : PnlDrawing.shapesArrList) {
			if(shape.isSelected()) {
				String[] split = shape.toString().split(" ");
				dlgRectangle.getTxtXCoordinate().setText(split[4]);
				dlgRectangle.getTxtYCoordinate().setText(split[7]);
				dlgRectangle.getTxtWidth().setText(split[13]);
				dlgRectangle.getTxtHeight().setText(split[16]);
			}
		}
		dlgRectangle.setVisible(true);
	}

	@Override
	public void AreaPainter(Graphics g) {
		g.setColor(getFill());
		g.fillRect(this.getUpperLeft().getX(), this.getUpperLeft().getY(), this.getWidth(), this.getHeight());
	}
	
	
}
