package geometry;

import java.awt.Color;
import java.awt.Graphics;

import drawing.DlgCircle;
import drawing.PnlDrawing;

public class Circle extends Shape{
	
	private Point center;
	private int radius;
	
	public Circle() {
		
	}
	
	public Circle(Point center, int radius) {
		this.center = center;
		this.radius = radius;
	}
	
	public Circle(Point center, int radius, boolean selected) {
		this(center, radius);
		this.selected = selected;
	}
	
	@Override
	public String toString() {
		return "Circle [center= " + center + " , radius= " + radius + " , selected= " + selected + "]";
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Circle) {
			Circle temp = (Circle) o;
			if(radius==temp.getRadius() && center.equals(temp.getCenter())) {
				return true;
			}
		}
		return false;
	}
	
	public double area() {
		return Math.PI*radius*radius;
	}
	
	public double circumference() {
		return 2*radius*Math.PI;
	}

	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	@Override
	public int compareTo(Object o) {
		if(o instanceof Circle) {
			return (int)(this.area()-((Circle)o).area());
		}
		return 0;
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(getOutline());
		g.drawOval(this.center.getX() - this.radius, this.center.getY() - this.radius, this.radius*2, this.radius*2);
		if(isSelected()==true) {
			g.setColor(Color.black);
			g.drawRect(this.center.getX()-3, this.center.getY()-3, 6, 6);//centar
			g.drawRect(this.center.getX()-3, this.center.getY()-this.radius-3, 6, 6);//gore
			g.drawRect(this.center.getX()-3, this.center.getY()+this.radius-3, 6, 6);//dole
			g.drawRect(this.center.getX()-this.radius-3, this.center.getY()-3, 6, 6);//levo
			g.drawRect(this.center.getX()+this.radius-3, this.center.getY()-3, 6, 6);//desno
		}
		
	}

	@Override
	public boolean contains(int x, int y) {
		return center.distance(new Point(x,y))<= this.radius;
	}

	@Override
	public void move(int newX, int newY) {
		center.move(newX, newY);
		
	}

	@Override
	public void DialogEdit() {
		DlgCircle dlgCircle = new DlgCircle();
		for(Shape shape : PnlDrawing.shapesArrList) {
			if(shape.isSelected()) {
				String[] split = shape.toString().split(" ");
				dlgCircle.getTxtXCoordinate().setText(split[4]);
				dlgCircle.getTxtYCoordinate().setText(split[7]);
				dlgCircle.getTxtRadius().setText(split[13]);
			}
		}
		dlgCircle.setVisible(true);
	}

	@Override
	public void AreaPainter(Graphics g) {
		g.setColor(getFill());
		g.fillOval(this.getCenter().getX() - this.getRadius(), this.getCenter().getY() - this.getRadius(), this.getRadius() * 2, this.getRadius() * 2);
	}
}
