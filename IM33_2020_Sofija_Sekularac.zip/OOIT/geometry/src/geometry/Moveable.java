package geometry;

public interface Moveable {

	void move(int newX, int newY);
}
