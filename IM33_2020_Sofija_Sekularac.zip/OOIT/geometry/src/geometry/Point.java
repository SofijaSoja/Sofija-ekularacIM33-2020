package geometry;

import java.awt.Color;
import java.awt.Graphics;

import drawing.DlgPoint;
import drawing.PnlDrawing;

public class Point extends Shape{
	
	private int x;
	private int y;
	
	public Point() {
		
	}
	
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Point(int x, int y, boolean selected) {
		//nasledjivanje konstruktora
		this(x,y);
		this.selected = selected;
	}
	
	@Override
	public String toString() {
		return "Point [x= " + x + " , y= " + y + " , selected= " + selected + "]";
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Point) {
			Point temp = (Point) o;
			if(x==temp.getX() && y==temp.getY()) {
				return true;
			}
		}
		return false;
	}
	
	public double distance(Point p1) {
		int dx = x - p1.x;
		int dy = y - p1.y;
		
		return Math.sqrt(dx*dx + dy*dy);
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(getOutline());
		g.drawLine(x-2, y, x+2, y); //Horizontalna   x
		g.drawLine(x, y-2, x, y+2); //Vertikalna y
		if(isSelected()==true) {
			g.setColor(Color.black);
			g.drawRect(this.getX()-3, this.getY()-3, 6, 6);
		}
		
	}

	@Override
	public boolean contains(int x, int y) {
			return distance(new Point(x,y))<=3;
	}

	@Override
	public void move(int newX, int newY) {
		this.x = newX;
		this.y = newY;
		
	}

	@Override
	public void DialogEdit() {
		DlgPoint dlgPoint = new DlgPoint();
		for(Shape shape : PnlDrawing.shapesArrList) {
			if(shape.isSelected()) {
				String[] split = shape.toString().split(" ");
				dlgPoint.getTxtXCoordinate().setText(split[2]);
				dlgPoint.getTxtYCoordinate().setText(split[5]);
			}
		}
		dlgPoint.setVisible(true);
		
	}

	@Override
	public void AreaPainter(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
