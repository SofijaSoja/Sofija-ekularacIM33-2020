package geometry;

import java.awt.Color;
import java.awt.Graphics;

import drawing.DlgCircle;
import drawing.DlgDonut;
import drawing.PnlDrawing;

public class Donut extends Circle{
	
	private int innerRadius;
	
	public Donut() {
		
	}
	
	public Donut(Point center, int radius, int innerRadius) {
		super(center,radius);
		this.innerRadius = innerRadius;
	}
	
	public Donut(Point center, int radius, int innerRadius, boolean selected) {
		super(center,radius,selected);
		this.innerRadius = innerRadius;
	}
	
	@Override
	public String toString() {
		return "Donut [ innerRadius= " + innerRadius + " , [Outer " + super.toString() + "]]";
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Donut) {
			Donut temp = (Donut) o;
			if(getRadius()==temp.getRadius() && getCenter().equals(temp.getCenter()) && innerRadius==temp.getInnerRadius()) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public void draw(Graphics g) {
		super.draw(g);
		g.drawOval(getCenter().getX()-innerRadius, getCenter().getY()-innerRadius, innerRadius*2, innerRadius*2);
	}

	public int getInnerRadius() {
		return innerRadius;
	}

	public void setInnerRadius(int innerRadius) {
		this.innerRadius = innerRadius;
	}
	
	@Override
	public boolean contains(int x,int y) {
		return super.contains(x,y) && getCenter().distance(new Point(x,y)) >= innerRadius;
	}
	
	@Override
	public void DialogEdit() {
		DlgDonut dlgDonut = new DlgDonut();
		for(Shape shape : PnlDrawing.shapesArrList) {
			if(shape.isSelected()) {
				String[] split = shape.toString().split(" ");
				dlgDonut.getTxtXCoordinate().setText(split[10]);
				dlgDonut.getTxtYCoordinate().setText(split[13]);
				dlgDonut.getTxtRadius().setText(split[19]);
				dlgDonut.getTxtInnerRadius().setText(split[3]);
			}
		}
		dlgDonut.setVisible(true);
	}
	
	@Override
	public void AreaPainter(Graphics g) {
		super.AreaPainter(g);
		g.setColor(getFill());
		g.drawOval(this.getCenter().getX() - this.getInnerRadius(), this.getCenter().getY() - this.getInnerRadius(), this.getInnerRadius() * 2, this.getInnerRadius() * 2);
		g.setColor(Color.WHITE);
		g.fillOval(this.getCenter().getX() - this.getInnerRadius(), this.getCenter().getY() - this.getInnerRadius(), this.getInnerRadius() * 2, this.getInnerRadius() * 2);
	}
	
	
}

