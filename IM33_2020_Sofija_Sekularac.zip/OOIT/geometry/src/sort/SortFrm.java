package sort;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import geometry.Circle;
import geometry.Point;
import stack.StackDlg;

import java.awt.BorderLayout;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.awt.event.ActionEvent;

public class SortFrm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	DefaultListModel<String> dlm = new DefaultListModel<String>();
	ArrayList<Circle> arrCircle = new ArrayList<>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SortFrm frame = new SortFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SortFrm() {
		setTitle("Sekularac Sofija IM33/2020");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 288, 302);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel pnlCenter = new JPanel();
		contentPane.add(pnlCenter, BorderLayout.CENTER);
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_pnlCenter = new GroupLayout(pnlCenter);
		gl_pnlCenter.setHorizontalGroup(
			gl_pnlCenter.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlCenter.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 245, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(171, Short.MAX_VALUE))
		);
		gl_pnlCenter.setVerticalGroup(
			gl_pnlCenter.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlCenter.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		JList list = new JList();
		list.setModel(dlm);
		scrollPane.setViewportView(list);
		pnlCenter.setLayout(gl_pnlCenter);
		
		JPanel pnlDown = new JPanel();
		contentPane.add(pnlDown, BorderLayout.SOUTH);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SortDlg sortDlg = new SortDlg();
				sortDlg.setVisible(true);
				if(sortDlg.isOk==true) {
					Circle circle = new Circle (new Point
							(Integer.parseInt(sortDlg.getTxtXCoordinate().getText()),
							(Integer.parseInt(sortDlg.getTxtYCoordinate().getText()))),
							(Integer.parseInt(sortDlg.getTxtRadius().getText())));
					arrCircle.add(circle);
					Collections.sort(arrCircle);
					dlm.add(arrCircle.indexOf(circle), "X: " + circle.getCenter().getX() + " , Y: " + circle.getCenter().getY() + " , Radius: "
							+ circle.getRadius());
					
				}
			}
		});
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dlm.isEmpty()) {
					JOptionPane.showMessageDialog(null, "The list is empty", "Error", JOptionPane.ERROR_MESSAGE);
					getToolkit().beep();
				}
				SortDlg sortdlgDel = new SortDlg();
				String[] split = dlm.firstElement().toString().split(" ");
				sortdlgDel.getTxtXCoordinate().setText(split[1]);
				sortdlgDel.getTxtYCoordinate().setText(split[4]);
				sortdlgDel.getTxtRadius().setText(split[7]);
				sortdlgDel.getTxtXCoordinate().setEditable(false);
				sortdlgDel.getTxtYCoordinate().setEditable(false);
				sortdlgDel.getTxtRadius().setEditable(false);
				sortdlgDel.setVisible(true);
				if(sortdlgDel.isDel()==true) {
					arrCircle.remove(0);
					dlm.removeElementAt(0);
					}
			}
		});
		GroupLayout gl_pnlDown = new GroupLayout(pnlDown);
		gl_pnlDown.setHorizontalGroup(
			gl_pnlDown.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlDown.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnAdd)
					.addGap(108)
					.addComponent(btnRemove)
					.addContainerGap(186, Short.MAX_VALUE))
		);
		gl_pnlDown.setVerticalGroup(
			gl_pnlDown.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_pnlDown.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_pnlDown.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAdd)
						.addComponent(btnRemove)))
		);
		pnlDown.setLayout(gl_pnlDown);
	}
}
