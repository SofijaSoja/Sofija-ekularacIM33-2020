package drawing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import geometry.Line;
import geometry.Point;
import geometry.Shape;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class DlgLine extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel pnlCenter = new JPanel();
	private JButton okButton;
	private JButton cancelButton;
	private JTextField txtXstart;
	private JTextField txtYstart;
	private JTextField txtXend;
	private JTextField txtYend;
	private JButton btnOutlineColor;
	private Color outline = Color.black;
	private boolean outlineBool;

	public boolean isOutlineBool() {
		return outlineBool;
	}

	public void setOutlineBool(boolean outlineBool) {
		this.outlineBool = outlineBool;
	}

	public Color getOutline() {
		return outline;
	}

	public void setOutline(Color outline) {
		this.outline = outline;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DlgLine dialog = new DlgLine();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DlgLine() {
		setTitle("Sekularac Sofija IM33/2020");
		setModal(true);
		setBounds(100, 100, 300, 300);
		getContentPane().setLayout(new BorderLayout());
		pnlCenter.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(pnlCenter, BorderLayout.CENTER);
		JLabel lblXStart = new JLabel("X coordinate start:");
		JLabel lblYStart = new JLabel("Y coordinate start:");
		JLabel lblXEnd = new JLabel("X coordinate end:");
		JLabel lblYEnd = new JLabel("Y coordinate end:");
		txtXstart = new JTextField();
		txtXstart.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar(); //char c dobija vrednost karaktera koje odgovara dugmetu pritisnutom na tast
				if(!((c>='0' &&  c<='9') || (c==KeyEvent.VK_BACK_SPACE))) { //provera da li je karakter nije izmedju 0 i 9 ili da li je pritisnut back space za brisanje karaktera
					e.consume();
					getToolkit().beep(); //zvuk koji se cuje kad se unese pogresno tj kad je ispunjen if 
				}
			}
		});
		txtXstart.setColumns(10);
		txtYstart = new JTextField();
		txtYstart.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar(); //char c dobija vrednost karaktera koje odgovara dugmetu pritisnutom na tast
				if(!((c>='0' &&  c<='9') || (c==KeyEvent.VK_BACK_SPACE))) { //provera da li je karakter nije izmedju 0 i 9 ili da li je pritisnut back space za brisanje karaktera
					e.consume();
					getToolkit().beep(); //zvuk koji se cuje kad se unese pogresno tj kad je ispunjen if 
				}
			}
		});
		txtYstart.setColumns(10);
		txtXend = new JTextField();
		txtXend.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar(); //char c dobija vrednost karaktera koje odgovara dugmetu pritisnutom na tast
				if(!((c>='0' &&  c<='9') || (c==KeyEvent.VK_BACK_SPACE))) { //provera da li je karakter nije izmedju 0 i 9 ili da li je pritisnut back space za brisanje karaktera
					e.consume();
					getToolkit().beep(); //zvuk koji se cuje kad se unese pogresno tj kad je ispunjen if 
				}
			}
		});
		txtXend.setColumns(10);
		txtYend = new JTextField();
		txtYend.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar(); //char c dobija vrednost karaktera koje odgovara dugmetu pritisnutom na tast
				if(!((c>='0' &&  c<='9') || (c==KeyEvent.VK_BACK_SPACE))) { //provera da li je karakter nije izmedju 0 i 9 ili da li je pritisnut back space za brisanje karaktera
					e.consume();
					getToolkit().beep(); //zvuk koji se cuje kad se unese pogresno tj kad je ispunjen if 
				}
			}
		});
		txtYend.setColumns(10);
		
		btnOutlineColor = new JButton("Change outline color");
		btnOutlineColor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				outline = JColorChooser.showDialog(null, "Choose a color", Color.BLACK);
				outlineBool = true;
			}
		});
		
		btnOutlineColor.setForeground(new Color(97, 16, 30));
		btnOutlineColor.setBackground(new Color(255, 255, 255));
		
		GroupLayout gl_pnlCenter = new GroupLayout(pnlCenter);
		gl_pnlCenter.setHorizontalGroup(
			gl_pnlCenter.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlCenter.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlCenter.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlCenter.createSequentialGroup()
							.addComponent(lblXStart)
							.addGap(18)
							.addComponent(txtXstart, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_pnlCenter.createSequentialGroup()
							.addGroup(gl_pnlCenter.createParallelGroup(Alignment.LEADING)
								.addComponent(lblYStart)
								.addComponent(lblXEnd)
								.addComponent(lblYEnd))
							.addGap(18)
							.addGroup(gl_pnlCenter.createParallelGroup(Alignment.LEADING)
								.addComponent(txtYend, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtXend, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtYstart, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(btnOutlineColor))
					.addContainerGap(83, Short.MAX_VALUE))
		);
		gl_pnlCenter.setVerticalGroup(
			gl_pnlCenter.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlCenter.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_pnlCenter.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblXStart)
						.addComponent(txtXstart, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_pnlCenter.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblYStart)
						.addComponent(txtYstart, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_pnlCenter.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblXEnd)
						.addComponent(txtXend, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_pnlCenter.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblYEnd)
						.addComponent(txtYend, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
					.addComponent(btnOutlineColor)
					.addContainerGap())
		);
		pnlCenter.setLayout(gl_pnlCenter);
		{
			JPanel btnPanel = new JPanel();
			getContentPane().add(btnPanel, BorderLayout.SOUTH);
			{
				okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(txtXstart.getText().trim().isEmpty() || txtYstart.getText().trim().isEmpty() || txtXend.getText().trim().isEmpty() || txtYend.getText().trim().isEmpty()) {
							JOptionPane.showMessageDialog(null, "Enter in all values!", "Error", JOptionPane.INFORMATION_MESSAGE);
							dispose();
						}else {
							for(Shape shape : PnlDrawing.shapesArrList) {
								if(shape.isSelected()) {
									((Line)shape).setStartPoint(new Point (Integer.parseInt(txtXstart.getText()), Integer.parseInt(txtYstart.getText())));
									((Line)shape).setEndPoint(new Point (Integer.parseInt(txtXend.getText()), Integer.parseInt(txtYend.getText())));
									if(outlineBool == true) {
										shape.setOutline(outline);
										outlineBool = false;
									}
								}
							}
						}
						dispose();
						return;
					}
				});
				okButton.setActionCommand("OK");
				getRootPane().setDefaultButton(okButton);
			}
			{
				cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
			}
			GroupLayout gl_btnPanel = new GroupLayout(btnPanel);
			gl_btnPanel.setHorizontalGroup(
				gl_btnPanel.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_btnPanel.createSequentialGroup()
						.addGap(131)
						.addComponent(okButton)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(cancelButton)
						.addGap(48))
			);
			gl_btnPanel.setVerticalGroup(
				gl_btnPanel.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_btnPanel.createSequentialGroup()
						.addGap(5)
						.addGroup(gl_btnPanel.createParallelGroup(Alignment.BASELINE)
							.addComponent(okButton)
							.addComponent(cancelButton)))
			);
			btnPanel.setLayout(gl_btnPanel);
		}
	}

	public JTextField getTxtXstart() {
		return txtXstart;
	}

	public void setTxtXstart(JTextField txtXstart) {
		this.txtXstart = txtXstart;
	}

	public JTextField getTxtYstart() {
		return txtYstart;
	}

	public void setTxtYstart(JTextField txtYstart) {
		this.txtYstart = txtYstart;
	}

	public JTextField getTxtXend() {
		return txtXend;
	}

	public void setTxtXend(JTextField txtXend) {
		this.txtXend = txtXend;
	}

	public JTextField getTxtYend() {
		return txtYend;
	}

	public void setTxtYend(JTextField txtYend) {
		this.txtYend = txtYend;
	}

}
