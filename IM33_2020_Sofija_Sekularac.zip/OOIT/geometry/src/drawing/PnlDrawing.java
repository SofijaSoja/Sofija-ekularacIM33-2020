package drawing;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JPanel;

import geometry.Circle;
import geometry.Donut;
import geometry.Line;
import geometry.Point;
import geometry.Rectangle;
import geometry.Shape;

public class PnlDrawing extends JPanel implements MouseListener{
	
	static int obj = 0;
	int mouseX, mouseY;
	public static ArrayList<Shape> shapesArrList = new ArrayList<Shape>();
	Point startLine = null;
	Point endLine;
	
	public PnlDrawing() {
		addMouseListener(this);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		mouseX = e.getX();
		mouseY = e.getY();
		
		switch(obj) {
		case 1:
			Point p = new Point(mouseX, mouseY, false);
			p.setOutline(DrawingFrm.outline);
			shapesArrList.add(p);
			System.out.println(shapesArrList);
			break;
		case 2:
			if(startLine==null) {
				startLine = new Point(mouseX, mouseY);
			}else {
				Point endLine = new Point(mouseX, mouseY);
				Line line = new Line(startLine, endLine, false);
				line.setOutline(DrawingFrm.outline);
				shapesArrList.add(line);
				startLine = null;
			}
			break;
		case 3:
			DlgRectangle dlgRectangle = new DlgRectangle();
			dlgRectangle.getTxtXCoordinate().setText(String.valueOf(mouseX));
			dlgRectangle.getTxtXCoordinate().setEditable(false);
			dlgRectangle.getTxtYCoordinate().setText(String.valueOf(mouseY));
			dlgRectangle.getTxtYCoordinate().setEditable(false);
			dlgRectangle.setVisible(true);
				if(dlgRectangle.isOk == true) {
					Rectangle r = new Rectangle(new Point(mouseX, mouseY),
					Integer.parseInt(dlgRectangle.getTxtWidth().getText()),
					Integer.parseInt(dlgRectangle.getTxtHeight().getText()),
					false);
				r.setOutline(DrawingFrm.outline);
				r.setFill(DrawingFrm.area);
				if(dlgRectangle.isOutlineBool()) {
					r.setOutline(dlgRectangle.getOutline());
				}
				if(dlgRectangle.isFillBool()) {
					r.setFill(dlgRectangle.getFill());
				}
				System.out.println(r);
				shapesArrList.add(r);
				}
			break;
		case 4:
			DlgCircle dlgCircle = new DlgCircle();
			dlgCircle.getTxtXCoordinate().setText(String.valueOf(mouseX));
			dlgCircle.getTxtYCoordinate().setText(String.valueOf(mouseY));
			dlgCircle.getTxtXCoordinate().setEditable(false);
			dlgCircle.getTxtYCoordinate().setEditable(false);
			dlgCircle.setVisible(true);
			if (dlgCircle.isOk == true) {
				Circle c = new Circle(new Point (mouseX, mouseY), Integer.parseInt(dlgCircle.getTxtRadius().getText()), false);
				c.setOutline(DrawingFrm.outline);
				c.setFill(DrawingFrm.area);
				if(dlgCircle.isOutlineBool()) {
					c.setOutline(dlgCircle.getOutline());
				}
				if(dlgCircle.isFillBool()) {
					c.setFill(dlgCircle.getFill());
				}
				shapesArrList.add(c);
			}
			break;
		case 5:
			DlgDonut dlgDonut = new DlgDonut();
			dlgDonut.getTxtXCoordinate().setText(String.valueOf(mouseX));
			dlgDonut.getTxtYCoordinate().setText(String.valueOf(mouseY));
			dlgDonut.getTxtXCoordinate().setEditable(false);
			dlgDonut.getTxtYCoordinate().setEditable(false);
			dlgDonut.setVisible(true);
			if(dlgDonut.isOk == true) {
				Donut d = new Donut(new Point(mouseX, mouseY),
				Integer.parseInt(dlgDonut.getTxtRadius().getText()),
				Integer.parseInt(dlgDonut.getTxtInnerRadius().getText()),
				false);
				d.setOutline(DrawingFrm.outline);
				d.setFill(DrawingFrm.area);
				if(dlgDonut.isOutlineBool()) {
					d.setOutline(dlgDonut.getOutline());
				}
				if(dlgDonut.isFillBool()) {
					d.setFill(dlgDonut.getFill());
				}
				shapesArrList.add(d);
			}
			break;
		case 6:
			boolean match = false;
			Collections.reverse(shapesArrList);
			for(Shape shape : shapesArrList) {
				shape.setSelected(false);
				if(match == false) {
					if(shape.contains(mouseX, mouseY)) {
						shape.setSelected(true);
						match = true;
					}
				}
			}
			Collections.reverse(shapesArrList);
			break;
			
		
		}
		
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		for(Shape shape : shapesArrList) {
			shape.AreaPainter(g);
			shape.draw(g);
		}
		repaint();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
