package drawing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import geometry.Circle;
import geometry.Donut;
import geometry.Line;
import geometry.Point;
import geometry.Rectangle;
import geometry.Shape;

import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DrawingFrm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private PnlDrawing pnlDrawing = new PnlDrawing();
	static Color outline = Color.BLACK;
	static Color area = Color.WHITE;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DrawingFrm frame = new DrawingFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DrawingFrm() {
		setTitle("Sekularac Sofija IM33/2020");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 490);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(15, 0, 15, 0));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		pnlDrawing.setBackground(Color.WHITE);
		pnlDrawing.setBorder(null);
		contentPane.add(pnlDrawing,BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(215, 215, 215));
		contentPane.add(panel, BorderLayout.WEST);
		
		JButton btnPoint = new JButton("Point");
		btnPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Shape shape : PnlDrawing.shapesArrList) {
					shape.setSelected(false);
				}
				PnlDrawing.obj = 1;
				
			}
		});
		btnPoint.setForeground(new Color(66, 83, 112));
		btnPoint.setBackground(new Color(255, 255, 255));
		btnPoint.setBorder(new LineBorder(new Color(27, 42, 66), 2));
		
		JButton btnLine = new JButton("Line");
		btnLine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Shape shape : PnlDrawing.shapesArrList) {
					shape.setSelected(false);
				}
				PnlDrawing.obj = 2;
			}
		});
		btnLine.setForeground(new Color(66, 83, 112));
		btnLine.setBackground(new Color(255, 255, 255));
		btnLine.setBorder(new LineBorder(new Color(27, 42, 66), 2));
		
		JButton btnCircle = new JButton("Circle");
		btnCircle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Shape shape : PnlDrawing.shapesArrList) {
					shape.setSelected(false);
				}
				PnlDrawing.obj = 4;
			}
		});
		btnCircle.setForeground(new Color(66, 83, 112));
		btnCircle.setBackground(new Color(255, 255, 255));
		btnCircle.setBorder(new LineBorder(new Color(27, 42, 66), 2));
		
		JButton btnRectangle = new JButton("Rectangle");
		btnRectangle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Shape shape : PnlDrawing.shapesArrList) {
					shape.setSelected(false);
				}
				PnlDrawing.obj = 3;
			}
		});
		btnRectangle.setForeground(new Color(66, 83, 112));
		btnRectangle.setBackground(new Color(255, 255, 255));
		btnRectangle.setBorder(new LineBorder(new Color(27, 42, 66), 2));
		
		JButton btnDonut = new JButton("Donut");
		btnDonut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(Shape shape : PnlDrawing.shapesArrList) {
					shape.setSelected(false);
				}
				PnlDrawing.obj = 5;
			}
		});
		btnDonut.setForeground(new Color(66, 83, 112));
		btnDonut.setBackground(new Color(255, 255, 255));
		btnDonut.setBorder(new LineBorder(new Color(27, 42, 66), 2));
		
		JButton btnSelect = new JButton("Select");
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(PnlDrawing.shapesArrList.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Nothing to select!", "Information", JOptionPane.INFORMATION_MESSAGE);
					return;
				}else {
					PnlDrawing.obj = 6;
				}
			}
		});
		btnSelect.setForeground(new Color(97, 16, 30));
		btnSelect.setBackground(new Color(255, 255, 255));
		
		
		JButton btnModify = new JButton("Modify");
		btnModify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (Shape shape : PnlDrawing.shapesArrList) {
					if (shape.isSelected()) {
						if (shape instanceof Circle) {
							Circle circle = (Circle) shape;
							circle.DialogEdit();
							repaint();
						} else if (shape instanceof Rectangle) {
							Rectangle rectangle = (Rectangle) shape;
							rectangle.DialogEdit();
							repaint();
						} else if (shape instanceof Point) {
							Point point = (Point) shape;
							point.DialogEdit();
							repaint();
						} else if (shape instanceof Line) {
							Line line = (Line) shape;
							line.DialogEdit();
							repaint();
						} else if (shape instanceof Donut) {
							Donut donut = (Donut) shape;
							donut.DialogEdit();
							repaint();
						}
					}
				}
			}
		});
		btnModify.setForeground(new Color(97, 16, 30));
		btnModify.setBackground(new Color(255, 255, 255));
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (PnlDrawing.shapesArrList.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Nothing to delete!", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				for (Shape shape : PnlDrawing.shapesArrList) {
					if (shape.isSelected()) {
						int ans = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete selected object?", "Warning", JOptionPane.YES_NO_OPTION);
						if (ans == 0) {
							PnlDrawing.shapesArrList.remove(shape);
						}
						return;
					}
				}
				JOptionPane.showMessageDialog(null, "Please select an object", "Error", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnDelete.setForeground(new Color(255, 255, 255));
		btnDelete.setBackground(new Color(255, 0, 0));
		
		JButton btnOutlineColor = new JButton("Outline color");
		btnOutlineColor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				outline = JColorChooser.showDialog(null, "Choose a color", Color.BLACK);
				if(outline == null) {
					outline = Color.BLACK;
				}
			}
		});
		btnOutlineColor.setForeground(new Color(97, 16, 30));
		btnOutlineColor.setBackground(new Color(255, 255, 255));
		
		JButton btnAreaColor = new JButton("Area color");
		btnAreaColor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				area = JColorChooser.showDialog(null, "Choose a color", Color.WHITE);
				if(area == null) {
					area = Color.WHITE;
				}
			}
		});
		btnAreaColor.setForeground(new Color(97, 16, 30));
		btnAreaColor.setBackground(new Color(255, 255, 255));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(btnPoint, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnLine, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnRectangle, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnCircle, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnDonut, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnDelete, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnSelect, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnModify, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
						.addComponent(btnOutlineColor, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnAreaColor, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(19)
					.addComponent(btnPoint)
					.addGap(18)
					.addComponent(btnLine)
					.addGap(18)
					.addComponent(btnRectangle)
					.addGap(18)
					.addComponent(btnCircle)
					.addGap(18)
					.addComponent(btnDonut)
					.addGap(37)
					.addComponent(btnSelect)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnModify)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnOutlineColor)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnAreaColor)
					.addPreferredGap(ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
					.addComponent(btnDelete)
					.addContainerGap())
		);
		panel.setLayout(gl_panel);
	}
}
