/**
 * 
 */
/**
 * 
 */
module IM_33_2020_Sekularac_Sofija {
	requires java.desktop;
}